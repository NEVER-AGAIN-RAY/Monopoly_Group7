# Monopoly Deal Training Handoff

This archive contains one trace plus the current training scripts and reports.

## Recommended Windows 5090 setup

Use Python 3.11+ and install PyTorch with CUDA from the official PyTorch selector.
Then run from the repository root after copying this archive contents into the repo:

```bash
MONOPOLY_TRAIN_SOURCES=deepseek \
MONOPOLY_MIN_TRAIN_ROWS=5000 \
MONOPOLY_TRAIN_EPOCHS=40 \
MONOPOLY_TRAIN_BATCH_SIZE=512 \
scripts/train_distilled_rankers.sh "data/distillation/local-baseline-20260524-080604.jsonl" "models/distillation/local-baseline-20260524-080604-multiseed-seed42"
```

After training, run the gameplay matrix:

```bash
MONOPOLY_MATRIX_GAMES=50 \
MONOPOLY_MATRIX_PLAYERS=2,3,4,5 \
MONOPOLY_MATRIX_OPPONENTS=easy,normal,hard \
scripts/evaluate_gameplay_matrix.sh \
  "models/distillation/local-baseline-20260524-080604-multiseed-seed42-mlp/candidate_ranker_mlp.json" \
  "models/distillation/local-baseline-20260524-080604-multiseed-seed42-gameplay-matrix"
```

If the trace is local heuristic only, set:

```bash
MONOPOLY_TRAIN_SOURCES=local_heuristic
```

Before treating the handoff as production-ready, inspect:

```bash
cat "models/distillation/local-baseline-20260524-080604-multiseed-seed42-run_summary.md"
cat "models/distillation/local-baseline-20260524-080604-multiseed-seed42-trace_audit.json"
cat "models/distillation/local-baseline-20260524-080604-multiseed-seed42-readiness.json"
```

For DeepSeek-quality production data, `readiness.json` must have `"mode": "production"` and `"ready": true`. A local heuristic run can prove the pipeline works, but it is not a production training dataset.

For multi-seed reporting, run `MONOPOLY_SEEDS=11,42,73 scripts/run_seed_replicates.sh "data/distillation/local-baseline-20260524-080604.jsonl" "models/distillation/local-baseline-20260524-080604-multiseed-seed42"` and inspect `models/distillation/local-baseline-20260524-080604-multiseed-seed42-seed_summary.md`. If the archive already contains `*-seed_summary.md` or `*-gameplay_matrix.md`, read those first for the aggregate result.

## Notes

- Java runtime evaluation still requires the Java/Maven project.
- The student model never emits arbitrary actions; it ranks Java-generated legal candidates.
- Read `docs/ai-delivery-checklist.md`, `docs/ai-distillation-plan.md`, and `docs/ai-cost-and-experiment-roadmap.md` before scaling.
