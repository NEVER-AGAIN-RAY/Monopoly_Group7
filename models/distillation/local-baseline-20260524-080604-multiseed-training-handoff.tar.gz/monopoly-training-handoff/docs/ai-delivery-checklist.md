# AI Delivery Checklist

Last updated: 2026-05-24.

## Current Status

The training and evaluation pipeline is runnable on the Mac. The current shell does not have `DEEPSEEK_API_KEY` or `MONOPOLY_DEEPSEEK_API_KEY`, so no production DeepSeek-labeled dataset has been collected in this checkout yet.

Do not describe local heuristic data as DeepSeek-quality data. It is a pipeline baseline.

## Local Baseline Artifacts

Trace:

- `data/distillation/local-baseline-20260524-080604.jsonl`

Main local multi-seed reports:

- `models/distillation/local-baseline-20260524-080604-multiseed-seed_summary.md`
- `models/distillation/local-baseline-20260524-080604-multiseed-seed_summary.json`
- `models/distillation/local-baseline-20260524-080604-multiseed-gameplay_matrix.md`
- `models/distillation/local-baseline-20260524-080604-multiseed-gameplay_matrix.json`

Local delivery archives:

- `models/distillation/local-baseline-20260524-080604-multiseed-artifacts.tar.gz`
- `models/distillation/local-baseline-20260524-080604-multiseed-training-handoff.tar.gz`

Machine-readable status:

```bash
python3 scripts/check_ai_delivery_status.py \
  --output models/distillation/local-baseline-20260524-080604-multiseed-delivery_status.json
```

Per-seed prefixes:

- `models/distillation/local-baseline-20260524-080604-multiseed-seed11`
- `models/distillation/local-baseline-20260524-080604-multiseed-seed42`
- `models/distillation/local-baseline-20260524-080604-multiseed-seed73`

Local multi-seed result:

- Rows: 4774
- Sessions: 60
- Teacher source: `local_heuristic`
- Production-ready runs: 0
- MLP validation top-1 mean/std: 0.810 / 0.016
- MLP validation MRR mean/std: 0.892 / 0.009
- Gameplay vs hard: 12 games requested, 9 natural completions, ranker win rate 0.250, average ranker board rank 1.83

## Production Run Command

Run the paid probe first:

```bash
DEEPSEEK_API_KEY=... \
MONOPOLY_PRODUCTION_RUN_ID=deepseek-run1 \
MONOPOLY_PROMPT_PRICE_PER_MILLION=<dashboard-prompt-price> \
MONOPOLY_COMPLETION_PRICE_PER_MILLION=<dashboard-completion-price> \
scripts/run_deepseek_production_pipeline.sh
```

Inspect:

- `models/distillation/deepseek-run1-probe-trace_audit.json`
- `models/distillation/deepseek-run1-probe-quality_report.md`
- `models/distillation/deepseek-run1-probe-cost_estimate.json`

Continue only after the probe is acceptable:

```bash
DEEPSEEK_API_KEY=... \
MONOPOLY_PRODUCTION_RUN_ID=deepseek-run1 \
MONOPOLY_PAID_CONFIRM=run-paid-overnight \
scripts/run_deepseek_production_pipeline.sh
```

## Production Completion Gate

The production goal is not complete until all of these are true:

- A merged DeepSeek trace exists.
- At least 5000 rows are present for the first production student.
- `scripts/audit_distillation_trace.py` passes with `--preferred-source deepseek --require-token-usage`.
- `scripts/check_training_readiness.py --mode production` writes `"ready": true`.
- `*-run_summary.md` says `production-ready`.
- A multi-seed summary has been generated from the production trace.
- Gameplay evaluation reports ranker win rate, board-rank metrics, natural completions, and end reasons.
- `scripts/check_ai_delivery_status.py --production-prefix <prefix>` exits with code 0.

## Windows 5090 Plan

Use the Windows laptop for 100k+ rows, longer epoch runs, or larger model-family sweeps. After extracting a handoff archive into the repo, run:

```bash
MONOPOLY_TRAIN_SOURCES=deepseek \
MONOPOLY_MIN_TRAIN_ROWS=5000 \
MONOPOLY_TRAIN_EPOCHS=40 \
MONOPOLY_TRAIN_BATCH_SIZE=512 \
scripts/train_distilled_rankers.sh \
  data/distillation/deepseek-run1-merged.jsonl \
  models/distillation/deepseek-run1
```

Then run multi-seed reporting:

```bash
MONOPOLY_SEEDS=11,42,73 \
MONOPOLY_TRAIN_SOURCES=deepseek \
MONOPOLY_MIN_TRAIN_ROWS=5000 \
scripts/run_seed_replicates.sh \
  data/distillation/deepseek-run1-merged.jsonl \
  models/distillation/deepseek-run1
```

## Report Boundaries

Safe current claim:

- The backend can generate legal decision rows, train MLP/linear/KNN students on Mac, export Java-loadable rankers, and evaluate gameplay with ranker win-rate and board-rank metrics.

Unsafe current claim:

- That the dataset is DeepSeek-quality.
- That the model is production-ready.
- That the gameplay result is robust enough for a paper claim.
