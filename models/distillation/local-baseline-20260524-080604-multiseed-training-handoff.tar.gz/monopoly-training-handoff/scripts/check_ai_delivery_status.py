#!/usr/bin/env python3
"""Write a concise delivery status report for Monopoly Deal AI artifacts."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Sequence


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--local-prefix", type=Path, default=Path("models/distillation/local-baseline-20260524-080604-multiseed"))
    parser.add_argument("--production-prefix", type=Path, default=None)
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args(argv)

    report = build_report(args.local_prefix, args.production_prefix)
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if report["productionReady"] else 1


def build_report(local_prefix: Path, production_prefix: Path | None) -> Dict[str, Any]:
    local_seed_summary = load_json(local_prefix.parent / f"{local_prefix.name}-seed_summary.json")
    local_gameplay = load_json(local_prefix.parent / f"{local_prefix.name}-gameplay_matrix.json")
    production_summary = load_json(production_prefix.parent / f"{production_prefix.name}-seed_summary.json") if production_prefix else {}
    production_readiness = load_json(production_prefix.parent / f"{production_prefix.name}-readiness.json") if production_prefix else {}
    production_ready = bool(production_summary.get("productionReadyRuns")) and bool(production_readiness.get("ready"))
    return {
        "schema": "monopoly-deal-ai-delivery-status-v1",
        "deepseekKeyPresent": bool(os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("MONOPOLY_DEEPSEEK_API_KEY")),
        "localPrefix": str(local_prefix),
        "localReadyRuns": int_number(local_seed_summary.get("readyRuns")),
        "localProductionReadyRuns": int_number(local_seed_summary.get("productionReadyRuns")),
        "localValidationTop1Mean": metric_mean(local_seed_summary, "validationTop1"),
        "localRankerWinRate": number(local_gameplay.get("rankerWinRate")),
        "localArtifacts": {
            "seedSummary": str(local_prefix.parent / f"{local_prefix.name}-seed_summary.md"),
            "gameplayMatrix": str(local_prefix.parent / f"{local_prefix.name}-gameplay_matrix.md"),
            "artifactsArchive": str(local_prefix.parent / f"{local_prefix.name}-artifacts.tar.gz"),
            "handoffArchive": str(local_prefix.parent / f"{local_prefix.name}-training-handoff.tar.gz"),
        },
        "productionPrefix": str(production_prefix) if production_prefix else "",
        "productionReady": production_ready,
        "productionReadinessMode": production_readiness.get("mode", "missing") if production_prefix else "not-run",
        "productionMissingReason": missing_reason(production_prefix, production_summary, production_readiness),
    }


def missing_reason(
        production_prefix: Path | None,
        production_summary: Dict[str, Any],
        production_readiness: Dict[str, Any]) -> str:
    if production_prefix is None:
        return "No production prefix was provided; DeepSeek production run has not been completed in this checkout."
    if not production_summary:
        return "Production multi-seed summary is missing."
    if not production_readiness:
        return "Production readiness report is missing."
    if not production_readiness.get("ready"):
        failures = [
            f"{item.get('name', 'unknown')}={item.get('detail', '')}"
            for item in production_readiness.get("checks", [])
            if isinstance(item, dict) and not item.get("ok")
        ]
        return "; ".join(failures) or "Production readiness is false."
    if not production_summary.get("productionReadyRuns"):
        return "Production seed summary has no production-ready runs."
    return ""


def metric_mean(summary: Dict[str, Any], metric: str) -> float:
    return number(obj(obj(summary.get("aggregates")).get(metric)).get("mean"))


def load_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    value = json.loads(path.read_text(encoding="utf-8"))
    return value if isinstance(value, dict) else {}


def obj(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def number(value: Any) -> float:
    try:
        if value is None or value == "":
            return 0.0
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def int_number(value: Any) -> int:
    return int(number(value))


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
