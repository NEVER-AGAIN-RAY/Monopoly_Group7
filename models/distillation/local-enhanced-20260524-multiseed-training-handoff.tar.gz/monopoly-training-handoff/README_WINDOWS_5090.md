# Monopoly Deal Training Handoff

This archive contains one trace plus the current training scripts and reports.

## Recommended Windows 5090 setup

Use Python 3.11+ and install PyTorch with CUDA from the official PyTorch selector.
Then run from the repository root after copying this archive contents into the repo:

```bash
MONOPOLY_TRAIN_SOURCES=deepseek \
MONOPOLY_MIN_TRAIN_ROWS=5000 \
MONOPOLY_TRAIN_EPOCHS=40 \
MONOPOLY_TRAIN_BATCH_SIZE=512 \
scripts/train_distilled_rankers.sh "data/distillation/local-enhanced-20260524.jsonl" "models/distillation/local-enhanced-20260524-multiseed"
```

After training, run the gameplay matrix:

```bash
MONOPOLY_MATRIX_GAMES=50 \
MONOPOLY_MATRIX_PLAYERS=2,3,4,5 \
MONOPOLY_MATRIX_OPPONENTS=easy,normal,hard \
scripts/evaluate_gameplay_matrix.sh \
  "models/distillation/local-enhanced-20260524-multiseed-mlp/candidate_ranker_mlp.json" \
  "models/distillation/local-enhanced-20260524-multiseed-gameplay-matrix"
```

If the trace is local heuristic only, set:

```bash
MONOPOLY_TRAIN_SOURCES=local_heuristic
```

Before treating the handoff as production-ready, inspect:

```bash
cat "models/distillation/local-enhanced-20260524-multiseed-run_summary.md"
cat "models/distillation/local-enhanced-20260524-multiseed-trace_audit.json"
cat "models/distillation/local-enhanced-20260524-multiseed-readiness.json"
```

For DeepSeek-quality production data, `readiness.json` must have `"mode": "production"` and `"ready": true`. A local heuristic run can prove the pipeline works, but it is not a production training dataset.

If this archive contains a local trace and a DeepSeek key becomes available, you can relabel stored legal candidates before running a new simulation:

```bash
DEEPSEEK_API_KEY=... \
scripts/run_relabel_paid_probe.sh \
  "data/distillation/local-enhanced-20260524.jsonl" \
  data/distillation/deepseek-relabel-probe.jsonl \
  models/distillation/deepseek-relabel-probe
```

The lower-level command is:

```bash
DEEPSEEK_API_KEY=... \
MONOPOLY_RELABEL_SELECT=true \
MONOPOLY_RELABEL_MAX_BY_KIND=PLAY_CARD:250,PAYMENT:120,JUST_SAY_NO:80,OVERFLOW_DISCARD:50 \
scripts/relabel_distillation_trace.sh \
  "data/distillation/local-enhanced-20260524.jsonl" \
  data/distillation/deepseek-relabel-probe.jsonl \
  models/distillation/deepseek-relabel-probe
```

This is a paid probe shortcut, not a production-ready shortcut; the relabeled trace still has to pass production readiness.

For multi-seed reporting, run `MONOPOLY_SEEDS=11,42,73 scripts/run_seed_replicates.sh "data/distillation/local-enhanced-20260524.jsonl" "models/distillation/local-enhanced-20260524-multiseed"` and inspect `models/distillation/local-enhanced-20260524-multiseed-seed_summary.md`. If the archive already contains `*-seed_summary.md` or `*-gameplay_matrix.md`, read those first for the aggregate result.

## Notes

- Java runtime evaluation still requires the Java/Maven project.
- The student model never emits arbitrary actions; it ranks Java-generated legal candidates.
- Read `docs/ai-delivery-checklist.md`, `docs/ai-distillation-plan.md`, and `docs/ai-cost-and-experiment-roadmap.md` before scaling.
- Run `python3 scripts/check_ai_quality_gate.py --require production --production-prefix <prefix>` before calling a dataset production-ready.
