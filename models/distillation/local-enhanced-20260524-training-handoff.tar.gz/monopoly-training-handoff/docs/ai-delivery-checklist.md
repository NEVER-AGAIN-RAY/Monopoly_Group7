# AI Delivery Checklist

Last updated: 2026-05-24.

## Current Status

The training and evaluation pipeline is runnable on the Mac. The current shell does not have `DEEPSEEK_API_KEY` or `MONOPOLY_DEEPSEEK_API_KEY`, so no production DeepSeek-labeled dataset has been collected in this checkout yet.

Do not describe local heuristic data as DeepSeek-quality data. It is a pipeline baseline.

## Local Baseline Artifacts

The preferred local handoff is the enhanced local baseline. It combines the first Mac baseline with an additional quota-driven local supplement so every decision kind clears the local readiness floor.

Trace:

- `data/distillation/local-enhanced-20260524.jsonl`
- supplement trace: `data/distillation/local-supplement-20260524-overflow.jsonl`
- merge report: `models/distillation/local-enhanced-20260524-trace_merge.json`

Main local reports:

- `models/distillation/local-enhanced-20260524-run_summary.md`
- `models/distillation/local-enhanced-20260524-run_summary.json`
- `models/distillation/local-enhanced-20260524-readiness.json`
- `models/distillation/local-enhanced-20260524-trace_audit.json`
- `models/distillation/local-enhanced-20260524-mlp/gameplay_vs_hard.json`

Local delivery archives:

- `models/distillation/local-enhanced-20260524-artifacts.tar.gz`
- `models/distillation/local-enhanced-20260524-training-handoff.tar.gz`

Machine-readable status:

```bash
python3 scripts/check_ai_delivery_status.py \
  --output models/distillation/local-enhanced-20260524-delivery_status.json
```

Local enhanced result:

- Rows: 6372
- Sessions: 134
- Teacher source: `local_heuristic`
- Decision mix: `PLAY_CARD=4490`, `PAYMENT=1340`, `JUST_SAY_NO=378`, `OVERFLOW_DISCARD=164`
- Player-count mix: 2/3/4/5 all present
- Status: `local-ready`
- Production-ready runs: 0
- MLP validation top-1: 0.815
- MLP validation MRR: 0.896
- First-candidate baseline: 0.357
- Random expected baseline: 0.223
- Gameplay vs hard: 4 games requested/evaluated, 4 natural completions, ranker win rate 0.500, average ranker board rank 1.75, board lead rate 0.500

Older multi-seed local baseline, kept for seed variance reference:

- `models/distillation/local-baseline-20260524-080604-multiseed-seed_summary.md`
- 4774 rows, validation top-1 mean/std 0.810 / 0.016, gameplay ranker win rate 0.250

## Production Run Command

Run the paid probe first:

```bash
DEEPSEEK_API_KEY=... \
MONOPOLY_PRODUCTION_RUN_ID=deepseek-run1 \
MONOPOLY_PROMPT_PRICE_PER_MILLION=<dashboard-prompt-price> \
MONOPOLY_COMPLETION_PRICE_PER_MILLION=<dashboard-completion-price> \
scripts/run_deepseek_production_pipeline.sh
```

Inspect:

- `models/distillation/deepseek-run1-probe-trace_audit.json`
- `models/distillation/deepseek-run1-probe-quality_report.md`
- `models/distillation/deepseek-run1-probe-cost_estimate.json`

If the API key arrives before there is time to run new simulations, relabel part of the existing local legal trace:

```bash
DEEPSEEK_API_KEY=... \
scripts/run_relabel_paid_probe.sh \
  data/distillation/local-enhanced-20260524.jsonl \
  data/distillation/deepseek-relabel-probe.jsonl \
  models/distillation/deepseek-relabel-probe
```

Lower-level equivalent:

```bash
DEEPSEEK_API_KEY=... \
MONOPOLY_RELABEL_SELECT=true \
MONOPOLY_RELABEL_MAX_BY_KIND=PLAY_CARD:250,PAYMENT:120,JUST_SAY_NO:80,OVERFLOW_DISCARD:50 \
scripts/relabel_distillation_trace.sh \
  data/distillation/local-enhanced-20260524.jsonl \
  data/distillation/deepseek-relabel-probe.jsonl \
  models/distillation/deepseek-relabel-probe
```

This is a fast paid probe because it reuses stored backend-legal candidates. The selector writes `models/distillation/deepseek-relabel-probe-selection_report.json` and spreads the paid subset across decision kinds, player counts, and sessions before relabeling. It is not by itself the production target: the enhanced local trace has enough local rows for a training smoke, but the production gate still needs at least 5000 DeepSeek rows, token usage metadata, and enough rare-kind coverage after relabeling or collection.

Continue only after the probe is acceptable:

```bash
DEEPSEEK_API_KEY=... \
MONOPOLY_PRODUCTION_RUN_ID=deepseek-run1 \
MONOPOLY_PAID_CONFIRM=run-paid-overnight \
scripts/run_deepseek_production_pipeline.sh
```

## Production Completion Gate

The production goal is not complete until all of these are true:

- A merged DeepSeek trace exists.
- At least 5000 rows are present for the first production student.
- `scripts/audit_distillation_trace.py` passes with `--preferred-source deepseek --require-token-usage`.
- `scripts/check_training_readiness.py --mode production` writes `"ready": true`.
- `*-run_summary.md` says `production-ready`.
- A multi-seed summary has been generated from the production trace.
- Gameplay evaluation reports ranker win rate, board-rank metrics, natural completions, and end reasons.
- `scripts/check_ai_delivery_status.py --production-prefix <prefix>` exits with code 0.

## Windows 5090 Plan

Use the Windows laptop for 100k+ rows, longer epoch runs, or larger model-family sweeps. After extracting a handoff archive into the repo, run:

```bash
MONOPOLY_TRAIN_SOURCES=deepseek \
MONOPOLY_MIN_TRAIN_ROWS=5000 \
MONOPOLY_TRAIN_EPOCHS=40 \
MONOPOLY_TRAIN_BATCH_SIZE=512 \
scripts/train_distilled_rankers.sh \
  data/distillation/deepseek-run1-merged.jsonl \
  models/distillation/deepseek-run1
```

Then run multi-seed reporting:

```bash
MONOPOLY_SEEDS=11,42,73 \
MONOPOLY_TRAIN_SOURCES=deepseek \
MONOPOLY_MIN_TRAIN_ROWS=5000 \
scripts/run_seed_replicates.sh \
  data/distillation/deepseek-run1-merged.jsonl \
  models/distillation/deepseek-run1
```

## Report Boundaries

Safe current claim:

- The backend can generate legal decision rows, train MLP/linear/KNN students on Mac, export Java-loadable rankers, and evaluate gameplay with ranker win-rate and board-rank metrics.

Unsafe current claim:

- That the dataset is DeepSeek-quality.
- That the model is production-ready.
- That the gameplay result is robust enough for a paper claim.
